<?php

use Illuminate\Database\Capsule\Manager as Capsule;

if (!defined("WHMCS"))
    die("This file cannot be accessed directly");

function ogcheckout_config() {
    $configarray = array(
        "name" => "Og Checkout",
        "description" => "Here You can manage Og Checkout payment options.",
        "version" => "1.0",
        "author" => "One Global",
        "language" => "english",
    );
    return $configarray;
}

function ogcheckout_activate() {   
    try {
        Capsule::schema()->dropIfExists('mod_ogcheckout');
        Capsule::schema()->create('mod_ogcheckout',function ($table) {                
                $table->increments('id');
                $table->string('name');
                $table->string('code');
                $table->string('currency');
                $table->string('method_mode');
                $table->string('method_mode_default');
                
            }
        );
    } catch (\Exception $e) {
        echo "Unable to create mod_ogcheckout: {$e->getMessage()}";
    }
    return array('status' => 'success', 'description' => 'Og Checkout Addon activated successfully');
}

function ogcheckout_deactivate() {
    Capsule::schema()->dropIfExists('mod_ogcheckout');
    return array('status' => 'success', 'description' => 'Og Checkout Addon deactivated successfully');
}

function ogcheckout_output($vars) {
    if (isset($_REQUEST['deleterecord'])) {
        $id = $_REQUEST['deleterecord'];
        Capsule::table('mod_ogcheckout')->where('id', '=', $id)->delete();        
        echo "<div class='alert alert-info'>Deleted Successfull</div>";
    }
    
    if (isset($_POST['method']))
    {
        $method = $_POST['method'];

        if (isset($_POST['method_mode']))
        {
            Capsule::table('mod_ogcheckout')->delete();
            foreach ($method as $key => $value)
            {
                $name = stripslashes($value['name']);
                $code = stripslashes($value['code']);
                $currency = stripslashes($value['currency']);
                $method_mode = 'customize';
                $method_mode_default = $_POST['method_mode'];
                
                
                if(strlen($name))
                {                    
                    try {                        
                        $insert_array = [
                            "name" => $name,
                            "code" => $code,
                            "currency" => $currency,
                            "method_mode"=>$method_mode,
                            "method_mode_default"=>$method_mode_default,
                        ];
                        Capsule::table('mod_ogcheckout')
                            ->insert($insert_array);
                    } catch(\Illuminate\Database\QueryException $ex){
                        echo $ex->getMessage();
                    } catch (Exception $e) {
                        echo $e->getMessage();
                    }
                }
            }

            $name = stripslashes($_POST['name']);
            $code = 'none';
            $currency = stripslashes($_POST['currency']);
            $method_mode = 'ogpayment';
            $method_mode_default = $_POST['method_mode'];
            if(strlen($name))
            {                    
                try {                        
                    $insert_array = [
                        "name" => $name,
                        "code" => $code,
                        "currency" => $currency,
                        "method_mode"=>$method_mode,
                        "method_mode_default"=>$method_mode_default,
                    ];
                    Capsule::table('mod_ogcheckout')
                        ->insert($insert_array);
                } catch(\Illuminate\Database\QueryException $ex){
                    echo $ex->getMessage();
                } catch (Exception $e) {
                    echo $e->getMessage();
                }
            }
        }elseif(isset($pageurl)){
            echo "<div class='alert alert-danger'>Please enter Details</div>";
        }
    }

    $sql = "SELECT * FROM mod_ogcheckout where `method_mode`='customize' order by id";
    $result = mysql_query($sql);
    $num_rows = mysql_num_rows($result);
    $data = mysql_fetch_array($result);
    
    $customizechecked = 'checked=checked';
    $ogpaymentchecked = '';
    $hidecustomize = '';
    $hideogpayment = 'display:none;';
    if($data['method_mode_default']=='ogpayment')
    {
        $ogpaymentchecked = 'checked=checked';
        $customizechecked = '';
        $hidecustomize = 'display:none;';
        $hideogpayment = '';

    }else if($data['method_mode_default']=='customize')
    {
        $customizechecked = 'checked=checked';
        $hideogpayment = 'display:none;';
        $hidecustomize = '';
    }

    echo '
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/css/dataTables.bootstrap.min.css" />
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>

    <div class="tab-content" style="padding-top:10px;">
        <form class="form-horizontal " action="" method="post" id="JqForm">
            <div id="menu1" class="tab-pane active">
            <div class="col-lg-3"></div>
            <div class="col-lg-9">
                <div class="row">
                    <label class="radio-inline"> <input type="radio" name="method_mode" value="customize" '.$customizechecked.'>Customize Your Payment Form</label> 
                    <label class="radio-inline"> <input type="radio" name="method_mode" value="ogpayment" '.$ogpaymentchecked.'>Og Checkout Payment Form</label>
                </div>
            </div>
            <br> <br>
            <div class="col-lg-12" id="customize-method" style="'.$hidecustomize.'">
            
            <table width="100%" id="example-table" class="table table-bordered">
            <thead>
                <tr>                            
                    <th class="tblhd2">Payment Method</th>
                    <th class="tblhd3">Channel Code</th>
                    <th class="tblhd4">Currency Code</th>
                    <th class="tblhd4"></th>
                </tr>
            </thead>
            <tbody>';
    /* Getting messages order by date desc */
    $sql = "SELECT * FROM mod_ogcheckout where `method_mode`='customize' order by id";
    $result = mysql_query($sql);
    $num_rows = mysql_num_rows($result);

    $p = 0;
    if($num_rows > 0){
        while($data = mysql_fetch_array($result)) {
            echo '<tr class="tblrow">';
            echo '<td><input type="text" class="form-control" name="method['.$p.'][name]" value="' . $data['name'] . '" ></td>';
            echo '<td><input type="text" class="form-control" name="method['.$p.'][code]" value="' . $data['code'] . '" ></td>';
            echo '<td><input type="text" class="form-control" name="method['.$p.'][currency]" value="' . $data['currency'] . '" ></td>'            
            . '<td>'
            . '<a href="addonmodules.php?module=ogcheckout&deleterecord=' . $data['id'] . '" onclick="return confirm(\'Are you sure?\')" title="delete">'
            . '<span class="glyphicon glyphicon-trash text-danger"></span></a> </td></tr>';
            $p++;
        }
    }

    echo '<tr class="tblrow newrow">';        
    echo '<td><input type="text" class="form-control" name="method['.$p.'][name]" value="" ></td>';
    echo '<td><input type="text" class="form-control" name="method['.$p.'][code]" value="" ></td>';
    echo '<td><input type="text" class="form-control" name="method['.$p.'][currency]" value="" ></td>'
        . '<td></td></tr>';
    
    echo '</tbody></table>
        <div class="col-lg-10 klm"><p align="center"><input type="hidden" value="'.$p.'" id="count" ><input type="submit" id="save" name="save" value="Save" class="btn btn-submit"/> <a href="javascript:void(0);" id="add_row" class="btn btn-submit">Add New</a>
<br> <br> </p></div>        
    ';

    $sql = "SELECT * FROM mod_ogcheckout where `method_mode`='ogpayment' order by id";
    $result = mysql_query($sql);    
    $data = mysql_fetch_array($result);

    echo '</div>
            <div class="col-lg-12" id="ogpayment-method"  style="'.$hideogpayment.'">        
                    <table width="100%" id="example-table" class="table table-bordered">
                    <thead>
                        <tr>                            
                            <th class="tblhd2">Payment Method</th>                           
                            <th class="tblhd4">Payment Currency</th>
                            <th class="tblhd4"></th>
                        </tr>
                    </thead>
                    <tbody>';
            echo '<tr class="tblrow">';
            echo '<td><input type="text" class="form-control" name="name" value="' . $data['name'] . '" ></td>';
            echo '<td><input type="text" class="form-control" name="currency" value="' . $data['currency'] . '" ></td></tr>';
    
    echo '</tbody></table>
        <div class="col-lg-10 klm"><p align="center"><input type="submit" id="save" name="save" value="Save" class="btn btn-submit"/>
<br> <br> </p></div>        
    ';
    echo '</div>';
            echo '</div>

    </div></form></div>';
    echo '<script type="text/javascript">
    $("input[name=\'method_mode\']").change(function(){
            var radioValue = $("input[name=\'method_mode\']:checked").val();
            if(radioValue=="customize"){
                $(\'#customize-method\').show();
                $(\'#ogpayment-method\').hide();
            }
            if(radioValue=="ogpayment"){
                $(\'#customize-method\').hide();
                $(\'#ogpayment-method\').show();
            }       
        });         
    $(document).ready(function()
    {

    })
</script>';
    echo '<script type="text/javascript">
$(document).ready(function()
{
$("#errorbox").delay(1000).fadeOut();
$("#successbox").delay(1000).fadeOut();
$("#updatebox").delay(1000).fadeOut();
});
$(document).ready(function(){

        $("#add_row").click(function(e){
            var i = parseInt($("#count").val());            
            i++;            
            e.preventDefault();
            $("#example-table").append(\'<tr><td><input type="text" class="form-control" name="method[\'+i+\'][name]" value=""></td><td><input type="text" class="form-control" name="method[\'+i+\'][code]" value=""></td><td><input type="text" class="form-control" name="method[\'+i+\'][currency]" value=""></td><td><a href="javascript:void(0);" class="remprow" title="delete"><span class="glyphicon glyphicon-trash text-danger"></span></a></td></tr>\');
            $("#count").val(i);
            $(".remprow").click(function(){        
                $(this).closest("tr").remove();
            });
        });
    $(".remprow").click(function(){        
        $(this).closest("tr").remove();
    });
});
</script>';
}
