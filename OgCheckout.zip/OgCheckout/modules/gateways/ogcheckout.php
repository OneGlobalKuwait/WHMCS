<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function ogcheckout_MetaData()
{
    return array(
        'DisplayName' => 'Og Checkout',
        'APIVersion' => '1.1', // Use API Version 1.1
        'DisableLocalCreditCardInput' => true,
        'TokenisedStorage' => false,
    );
}

function ogcheckout_config()
{
    return array(
        // the friendly display name for a payment gateway should be
        // defined here for backwards compatibility
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'Og Checkout',
        ),
        // a text field type allows for single line text input
        'merchantCode' => array(
            'FriendlyName' => 'Merchant Code',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your Merchant Code here',
        ),
        // a password field type allows for masked text input
        'authKey' => array(
            'FriendlyName' => 'auth Key',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter auth key here',
        ),
        'secretkey' => array(
            'FriendlyName' => 'Secret Key',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter Secret key here',
        ),
        'endpoint_url' => array(
            'FriendlyName' => 'Endpoint URL',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter Endpoint URL here',
        ),
        'language' => array(
            'FriendlyName' => 'Language',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter Language here',
        ),
        'tunnel' => array(
            'FriendlyName' => 'Tunnel',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter Tunnel here',
        ),
        'configuration' => array(
            'FriendlyName' => 'Payment configuration',
            'Description'=>'
                    Save current configuration and <a href="addonmodules.php?module=ogcheckout" target="_blank">Add Payment Methods</a>.'
        ),
        /*'payment_name' => array(
            'FriendlyName' => 'Payment Methods',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Refer to Documentation',
        ),
        'payment_currency' => array(
            'FriendlyName' => 'Payment Currency',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Leave this field blank when you use "all" parameters in payment method',
        ),*/     
    );
}

function ogcheckout_link($params)
{
    // Gateway Configuration Parameters
    $merchantCode = $params['merchantCode'];
    $authKey = $params['authKey'];
    $secretkey = $params['secretkey'];
    $endpoint_url = $params['endpoint_url'];
    $tunnel = $params['tunnel'];
    $language = $params['language'];   

    // Invoice Parameters
    $invoiceId = $params['invoiceid'];
    $description = $params["description"];
    $amount = $params['amount'];
    $currencyCode = $params['currency'];

    // Client Parameters
    $firstname = $params['clientdetails']['firstname'];
    $lastname = $params['clientdetails']['lastname'];
    $email = $params['clientdetails']['email'];
    $address1 = $params['clientdetails']['address1'];
    $address2 = $params['clientdetails']['address2'];
    $city = $params['clientdetails']['city'];
    $state = $params['clientdetails']['state'];
    $postcode = $params['clientdetails']['postcode'];
    $country = $params['clientdetails']['country'];
    $phone = $params['clientdetails']['phonenumber'];    

    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $returnUrl = $params['returnurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    $url = 'https://www.demopaymentgateway.com/do.payment';    

    $paymentCode = $params['payment_name'];
    $doConvert = "N";
    $sourceCurrency = '';

    $sql = "SELECT * FROM mod_ogcheckout limit 1";
    $result = mysql_query($sql);
    $data = mysql_fetch_array($result);
    

    if(strtolower($data['method_mode_default'])=='customize')
    {
        $sql = "SELECT * FROM mod_ogcheckout where `method_mode`='customize' order by id";
        $result = mysql_query($sql);
        $num_rows = mysql_num_rows($result);

        $p = 0;
        $custompayment = array();
        if($num_rows > 0){
            while($data = mysql_fetch_array($result)) {
                $custompayment[] = array('name'=>$data['name'],'code'=>$data['code'],'currency'=>$data['currency']);
            }
        }
    }else{
        $sql = "SELECT * FROM mod_ogcheckout where `method_mode`='ogpayment'";
        $result = mysql_query($sql);
        $data = mysql_fetch_array($result);

        $paymentCode = $data['name'];
        if(strlen($data['currency']))
        {
            $sourceCurrency = $currencyCode;
            $currencyCode =  $data['currency'];

        }        
    }
    
    $_SESSION['x_invoice_id'] = $invoiceId;
    $_SESSION['x_amount'] = $amount;
    $_SESSION['systemUrl'] = $systemUrl;

    $ref = generateRefrenceId($invoiceId);
    $timestamp = date("y/m/d H:m:s t");    
    $callback = $systemUrl . 'modules/gateways/callback/' . $moduleName . '.php';
    $userReference = generateUserRefrenceId($phone);

    $datatocomputeHash = $amount.$authKey.$currencyCode.$merchantCode.$paymentCode.$ref.$sourceCurrency.$timestamp.$tunnel.$userReference;
        
    $hash = strtoupper(hash_hmac("sha256", $datatocomputeHash,$secretkey));

    $postfields = array(
              'merchantCode' => $merchantCode,
              'authKey' => $authKey,
              'currency' => $currencyCode,
              'pc'=> $paymentCode,
              'tunnel'=> $tunnel,
              'amount'=> (float)$amount,
              'doConvert'=> $doConvert,
              'sourceCurrency'=> $sourceCurrency,
              'description'=> $description,
              'referenceID'=> (int)$ref,
              'timeStamp'=> $timestamp,
              'language'=> $language,
              'callbackURL'=> $callback,
              'hash'=> $hash,
              'userReference'=> (int)$userReference,
              'billingDetails'=> array(
                    'fName'=> $firstname,
                    'lName'=> $lastname,
                    'mobile'=> $phone,
                    'email'=> $email,
                    'city'=> $city,
                    'pincode'=> $postcode,
                    'state'=> $state,
                    'address1'=> $address1,
                    'address2'=> $address2
              ),
        );

        $url = $systemUrl . '/modules/gateways/callback/ogcheckout_processpayment.php';

    $htmlOutput = '<link href="modules/addons/ogcheckout/css/ogcheckout.css" rel="stylesheet" type="text/css">
    <form method="post" action="' . $url . '">';
    foreach ($postfields as $k => $v) {
        if(is_array($v))
        {
            foreach ($v as $vkey => $vvalue) {
                $htmlOutput .= '<input type="hidden" name="billingDetails['.$vkey.']" value="' . $vvalue . '" />';
            }
            continue;
        }
        $htmlOutput .= '<input type="hidden" name="' . $k . '" value="' . $v . '" />';
        
    }
    if(!empty($custompayment))
    {
        $p = 0;
        foreach ($custompayment as $key => $value) {
            $checked = '';
            if($p==0)
            {
                $checked = 'checked=checked';
            }
            $htmlOutput .= '<div class="radio radio_payment">
                <label>
                <input type="hidden" name="customcurrency['.trim($value['code']).']" value="'.trim($value['currency']).'">
                <input type="radio" name="pc" value="'.trim($value['code']).'" class="pc" '.$checked.'>
                '.$value['name'].'
                </label>
                <span><img src="https://checkoutadmin.oneglobal.com/pgimages/'.$value['code'].'.png"></span>
            </div>';
            $p++;
        }
    }
    $htmlOutput .= '<input type="submit" class="btn btn-success btn-sm" value="' . $langPayNow . '" />';
    $htmlOutput .= '</form>';

    return $htmlOutput;
}

function generateUserRefrenceId($uref=""){

        $digits_needed = 10;
        $uref = preg_replace("/[^0-9]/", "", $uref);
        $length = strlen($uref);
        
        if($length<$digits_needed){
        
            $required = $digits_needed-$length;
            
            $id='';
            for ($i = 1; $i <= $required; $i++) {
                   $id .= 1;
            }
            
            $refrenceId = $id.$uref;
        }else{
            $refrenceId = $id.$uref;
        }
        
        return (int)$refrenceId;
    }

    function generateRefrenceId($orderid)
    {
        $digits_needed = 15;
        
        $orderid = time().$orderid;
        
        $length = strlen((int)$orderid);
        
        if($length<$digits_needed){
        
            $required = $digits_needed-$length;
            
            $id='';
            for ($i = 1; $i <= $required; $i++) {
                   $id .= 1;
            }
            
            $refrenceId = $id.$orderid;
        }else{
            $refrenceId = $id.$orderid;
        }
        
        return (int)$refrenceId;
    }