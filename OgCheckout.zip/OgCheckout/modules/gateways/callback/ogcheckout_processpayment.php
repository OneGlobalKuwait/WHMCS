<?php
/**
 * WHMCS Sample Payment Callback File
 *
 * This sample file demonstrates how a payment gateway callback should be
 * handled within WHMCS.
 *
 * It demonstrates verifying that the payment gateway module is active,
 * validating an Invoice ID, checking for the existence of a Transaction ID,
 * Logging the Transaction for debugging and Adding Payment to an Invoice.
 *
 * For more information, please refer to the online documentation.
 *
 * @see https://developers.whmcs.com/payment-gateways/callbacks/
 *
 * @copyright Copyright (c) WHMCS Limited 2017
 * @license http://www.whmcs.com/license/ WHMCS Eula
 */

// Require libraries needed for gateway module functions.
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';

// Detect module name from filename.
$gatewayModuleName = basename('ogcheckout');

if(isset($_POST) && isset($_POST['merchantCode']))
{
    $gatewayParams = getGatewayVariables($gatewayModuleName);
    $endpoint = $gatewayParams['endpoint_url'];
    $merchantCode = $gatewayParams['merchantCode'];    
    $authKey = $gatewayParams['authKey'];
    $secretkey = $gatewayParams['secretkey'];
    $configuration = ($gatewayParams['configuration']) ? $gatewayParams['configuration'] : 'Og Checkout Payment Form';
    $timestamp = date("y/m/d H:m:s t");    

    if ($endpoint) {
        $curl = curl_init($endpoint);
    } else {
        $curl = curl_init('https://ogpaystage.oneglobal.com/OgPay/V1/api/GenToken/Validate');
    }
    $postdata = array();   

    $sql = "SELECT * FROM mod_ogcheckout limit 1";
    $result = mysql_query($sql);
    $data = mysql_fetch_array($result);

    if(strtolower($data['method_mode_default'])=='customize')
    {
        if($_POST['pc']==$_POST['currency']){
            $_POST['doConvert'] = "N";
           // $_POST['sourceCurrency'] = "";
        }else{
            $_POST['doConvert'] = "Y";            
            $_POST['sourceCurrency'] = trim($_POST['currency']);
            $_POST['currency'] = trim($_POST['customcurrency'][$_POST['pc']]);
        }       
        unset($_POST['customcurrency']);
    }else{
        if($_POST['pc']=='currency')
        {
            $_POST['doConvert'] = "Y";
        }
    }
    
    $postdata = $_POST;
    $postdata['amount'] = (int)$_POST['amount'];
    $postdata['referenceID'] = (int)$_POST['referenceID'];
    $postdata['userReference'] = (int)$_POST['userReference'];

    $datatocomputeHash = $_POST['amount'].$authKey.$_POST['currency'].$merchantCode.$_POST['pc'].$_POST['referenceID'].$_POST['sourceCurrency'].$timestamp.$_POST['tunnel'].$_POST['userReference'];
    $hash = strtoupper(hash_hmac("sha256", $datatocomputeHash,$secretkey));
    
    $postdata['hash'] = $hash;
    $postdata['timeStamp'] = $timestamp;
    
    $request = json_encode($postdata);
    
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $request);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));         
    $ch = curl_exec($curl);
    curl_close($curl);

    $response = json_decode($ch,true);

    if($response['errorCode']=='0'){        
          header("Location: ".$response['result']['redirectURL'],true,301);
    }else{
        echo '<pre>';
        print_r($_POST);
        print_r($response);
        $returnParam['error'] = 'Y';
        $returnParam['errorMessgae'] = $response['errorMessgae'];
    }
}