<?php
add_hook('ClientAreaFooterOutput', 1, function($vars) {
	
	if($vars['filename']=='cart' && $_GET['a']=='complete' && $_SESSION['orderdetails']['PaymentMethod']=='ogcheckout')
	{
        $sql = "SELECT * FROM mod_ogcheckout limit 1";
        $result = mysql_query($sql);
        $data = mysql_fetch_array($result);

        if(strtolower($data['method_mode_default'])=='customize')
        {
            return '<script language="javascript">
                    function autoSubmitFormByContainer(t)
                    {
                        return false;
                    }
                    $(".alert-info").html("Please select the option");
                    $(".text-center").find("img[alt*=\'Loading\']").remove()
                </script>';
        }
	}	
});
?>
  
